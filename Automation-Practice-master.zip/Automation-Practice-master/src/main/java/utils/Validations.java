package utils;

public class Validations {
    //TODO: Implement a custom validations class to enhance logging and to have implementation for soft assertions

}
